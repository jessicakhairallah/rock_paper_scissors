

<?php $__env->startSection('content'); ?>

<!-- Banner Section -->
<section class="banner-section">
  <div class="banner-carousel owl-theme owl-carousel">
    <!-- Slide Item -->
    <div class="slide-item">
      <div class="image-layer" style="background-image:url(images/main-slider/2.jpg)"></div>
        <div class="auto-container">
          <div class="content-box">
            <h2>Rock, Paper, Scissors</h2>
            <div class="btn-box"><a href="#" data-target="#view-demo" class="theme-btn btn-style-one scroll-to-target"><span class="btn-title">View Demo</span></a></div>
          </div>  
        </div>
    </div>
    <!-- Slide Item -->
    <div class="slide-item">
      <div class="image-layer" style="background-image:url(images/main-slider/3.jpg)"></div>
        <div class="auto-container">
          <div class="content-box">
            <h2>Play Now</h2>
            <div class="btn-box"><a href="<?php echo e(route('play_path')); ?>" class="theme-btn btn-style-one"><span class="btn-title">Play</span></a></div>
          </div>  
        </div>
    </div>
  </div>
</section>
<!--End Banner Section -->

<!-- Welcome Section -->
<section class="welcome-section">
  <div class="auto-container">
    <!-- Sec Title -->
    <div class="sec-title centered">
      <div class="title">Welcome to te Famous Game</div>
      <!-- <h2>Rock, Paper, Scissors</h2> -->
    </div>
    
    <div class="row clearfix">
      
      <!--Default Portfolio Item-->
      <div class="default-portfolio-item col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
        <div class="inner-box hvr-bob">
          <figure class="image-box"><img src="images/results/1.png" alt=""></figure>
          <!--Overlay Box-->
          <div class="overlay-box">
            <div class="overlay-inner">
              <div class="content">
                <h3><a class="pointer-none">Rock</a></h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!--Default Portfolio Item-->
      <div class="default-portfolio-item col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
        <div class="inner-box hvr-bob">
          <figure class="image-box"><img src="images/results/2.png" alt=""></figure>
          <!--Overlay Box-->
          <div class="overlay-box">
            <div class="overlay-inner">
              <div class="content">
                <h3><a class="pointer-none">Paper</a></h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!--Default Portfolio Item-->
      <div class="default-portfolio-item col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1500ms">
        <div class="inner-box hvr-bob">
          <figure class="image-box"><img src="images/results/3.png" alt=""></figure>
          <!--Overlay Box-->
          <div class="overlay-box">
            <div class="overlay-inner">
              <div class="content">
                <h3><a class="pointer-none">Scissors</a></h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      
    </div>
    
    <!-- Lower Box -->
    <div class="lower-box">
      <div class="text">Rock paper scissors is a hand game usually played between two people, in which each player simultaneously forms one of three shapes with an outstretched hand.<br>A player who decides to play rock will beat another player who has chosen scissors ("rock crushes scissors"), but will lose to one who has played paper ("paper covers rock"); a play of paper will lose to a play of scissors ("scissors cuts paper"). If both players choose the same shape, the game is tied and is usually immediately replayed to break the tie.</div>
      <a href="<?php echo e(route('play_path')); ?>" class="theme-btn btn-style-one"><span class="btn-title">Play</span></a>
    </div>
  </div>
</section>

<!-- Demo Section -->
<section class="matches-section" id="view-demo">
  <div class="auto-container">
    <div class="sec-title centered">
      <div class="title">Watch Live</div>
      <h2>Demo</h2>
    </div>
    
    <div class="matches-info-tabs">
      <div class="matches-tabs tabs-box">
      
        <ul class="tab-btns tab-buttons clearfix">
          <li data-tab="#prod-all" class="tab-btn active-btn"><span>Demo</span></li>
        </ul>
        
        <div class="tabs-content">
          
          <div class="tab active-tab" id="prod-all">
            <div class="content">
              
              <div class="matches-block">
                <div class="inner-block">
                  <div class="row clearfix">
                    
                    <div class="match-column col-lg-12 col-md-12 col-sm-12">
                      <div class="inner-column">
                        <div class="row clearfix">
                          
                          <div class="match-item col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-item">
                              <div class="icon-box">
                                <span class="icon flaticon-lion"></span>
                              </div>
                              <a href="#" class="product">Computer 1</a>
                            </div>
                          </div>
                          
                          <div class="match-item col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-item">
                              <div class="icon-box">
                                <span class="icon flaticon-wolf"></span>
                              </div>
                              <a href="#" class="product">Computer 2</a>
                            </div>
                          </div>

                          <div class="match-item col-lg-12 col-md-12 col-sm-12 centered mt-5">
                            <a href="#" onclick="playDemo()" data-toggle="modal" data-target="#game_modal" class="theme-btn btn-style-one"><span class="btn-title">Start Demo</span></a>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                  </div>
                </div>
              </div>                
              
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</section>

<!-- Modal -->
<div id="game_modal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Computer1 Vs Compouter2</h4>
      </div>
      <div class="modal-body">
        <div class="auto-container">
          <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="news-block col-lg-6 col-md-6 col-sm-6" style="visibility: visible !important;width: 50%; float: left;">
                <div class="inner-box hvr-bob">
                  <div class="image">
                    <li class="slide-item"><figure class="image-box"><img id="c1img" src="" alt=""></figure></li>
                  </div>
                  <div class="lower-content">
                    <div class="post-date"><i class="fa fa-hand-rock"></i></div>
                    <div class="post-date"><i class="fa fa-hand-paper"></i></div>
                    <div class="post-date"><i class="fa fa-hand-scissors"></i></div>
                    <h3 class="text-center" id="c1">C1 Wins</h3>
                  </div>
                </div>
              </div>
              <div class="news-block col-lg-6 col-md-6 col-sm-6" style="visibility: visible !important;;width: 50%; float: left;">
                <div class="inner-box hvr-bob">
                  <div class="image">
                    <li class="slide-item"><figure class="image-box"><img id="c2img" src="" alt=""></figure></li>
                  </div>
                  <div class="lower-content">
                    <div class="post-date"><i class="fa fa-hand-rock"></i></div>
                    <div class="post-date"><i class="fa fa-hand-paper"></i></div>
                    <div class="post-date"><i class="fa fa-hand-scissors"></i></div>
                    <h3 class="text-center" id="c2">C2 Wins</h3>
                  </div>
                </div>
              </div>
              <div class="col-lg-12 col-md-12 col-sm-12 text-center">
                <a onclick="playDemo()" class="theme-btn btn-style-one white-hover"><span class="btn-title">Try again</span></a>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript">

  function playDemo()
  {
    //remove old info
    $('#c1').html('');
    $('#c2').html('');
    // remove the old displayed image
    $('#c1img').attr('src', '');
    $('#c2img').attr('src', '');

    //generate 2 random numbers between 1 and 3 for c1 and c2
    var rand1=randomNumberFromRange(1, 3);
    var rand2=randomNumberFromRange(1, 3);

    //fill the iamges we get accordingly
    $('#c1img').attr('src', '/images/results/'+rand1+'.png');
    $('#c2img').attr('src', '/images/results/'+rand2+'.png');

    //if rock vs rock || paper vs paper || scissors vs scissors
    if((rand1==1 && rand2==1) || (rand1==2 && rand2==2) || (rand1==3 && rand2==3))
    {
      $('#c1').html('C1 Winner');
      $('#c2').html('C2 Winner');
    }
    //if rock vs paper || paper vs scissors || scissors vs rock
    if((rand1==1 && rand2==2) || (rand1==2 && rand2==3) || (rand1==3 && rand2==1) )
    {
      $('#c1').html('C1 Loser');
      $('#c2').html('C2 Winner');
    }
    //if rock vs scissors || paper vs rock || scissors vs paper
    if(rand1==1 && rand2==3 || (rand1==2 && rand2==1) || (rand1==3 && rand2==2))
    {
      $('#c1').html('C1 Winner');
      $('#c2').html('C2 Loser');
    }

  }

  //function to get random numbers between 1 and 3
  function randomNumberFromRange(min,max)
  {
    return Math.floor(Math.random()*(max-min+1)+min);
  }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/game/resources/views/index.blade.php ENDPATH**/ ?>