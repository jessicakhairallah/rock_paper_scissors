<!-- Main Footer -->
<footer class="main-footer">
  <div class="auto-container">
    <div class="widgets-section">
      <div class="row clearfix">
        <div class="column col-lg-6 col-md-6 col-sm-6">
          <div class="footer-widget logo-widget">
            <div class="logo">
              <a href="<?php echo e(route('home_path')); ?>"><img src="/images/logo.png" alt="" /></a>
            </div>
            <div class="text">Rock paper scissors is a hand game usually played between two people, in which each player simultaneously forms one of three shapes with an outstretched hand.</div>
          </div>
        </div>
        <div class="column col-lg-6 col-md-6 col-sm-6">
          <div class="footer-widget links-widget">
            <div class="widget-content">
              <div class="footer-title">
                <h2>Links</h2>
              </div>
              <div class="row clearfix">
                <div class="column col-lg-6 col-md-6 col-sm-6">
                  <ul class="list">
                    <li><a href="<?php echo e(route('home_path')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('play_path')); ?>">Play</a></li>
                  </ul>
                </div>
              </div>
            </div>  
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="footer-bottom">
    <div class="auto-container">
      <div class="scroll-to-top scroll-to-target" data-target="html"><span class="flaticon-up-arrow"></span></div>
      <div class="row clearfix">
        <div class="column col-lg-6 col-md-12 col-sm-12">
          <div class="copyright">&copy; Copyrights, 2020 All Rights Reserved. Jessica Khairallah</div>
        </div>
        <div class="column col-lg-6 col-md-12 col-sm-12">
          <ul class="social-icons">
            <li><a href="https://www.facebook.com/jessica.khairallah" target="_blank"><span class="fab fa-facebook-square"></span></a></li>
            <li><a href="https://www.instagram.com/jessicakhairallah93/" target="_blank"><span class="fab fa-instagram"></span></a></li>
            <li><a href="https://www.linkedin.com/in/jessica-khairallah-996a5385/" target="_blank"><span class="fab fa-linkedin"></span></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer><?php /**PATH /home/vagrant/Code/game/resources/views/layouts/footer.blade.php ENDPATH**/ ?>