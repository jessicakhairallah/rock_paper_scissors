<?php $url = Request::path(); ?>
<!-- Main Header -->
<header class="main-header">
    <!-- Header Top -->
    <div class="header-top">
        <div class="auto-container clearfix">

            <div class="top-left clearfix">
                <ul class="info-list">
                    <li>Welcome to Rock, Paper, Scissors game</li>
                </ul>
            </div>

            <div class="top-right">
                <ul class="social-icons">
                    <li><a href="https://www.facebook.com/jessica.khairallah" target="_blank"><span class="fab fa-facebook-square"></span></a></li>
                    <li><a href="https://www.instagram.com/jessicakhairallah93/" target="_blank"><span class="fab fa-instagram"></span></a></li>
                    <li><a href="https://www.linkedin.com/in/jessica-khairallah-996a5385/" target="_blank"><span class="fab fa-linkedin"></span></a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Header Upper -->
    <div class="header-upper">
        <div class="inner-container">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo-outer">
                    <div class="logo"><a href="<?php echo e(route('home_path')); ?>"><img src="images/logo.png" alt="logo" title="Rock, Paper, Scissors logo"></a></div>
                </div>

                <!--Nav Box-->
                <div class="nav-outer clearfix">
                    <!--Mobile Navigation Toggler-->
                    <div class="mobile-nav-toggler"><span class="icon flaticon-menu-1"></span></div>

                    <!-- Main Menu -->
                    <nav class="main-menu navbar-expand-md navbar-light">
                        <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                            <ul class="navigation clearfix pull-left">
                                <li class="<?php echo e(($url == '/') ? 'current' : ''); ?>"><a href="<?php echo e(route('home_path')); ?>">Home</a></li>
                            </ul>
                            <ul class="navigation pull-right clearfix">
                                <li class="<?php echo e(($url == 'play') ? 'current' : ''); ?>"><a href="<?php echo e(route('play_path')); ?>">Play</a></li>
                            </ul>
                        </div>
                    </nav>
                    <!-- Main Menu End-->
                </div>
            </div>
        </div>
    </div>
    <!--End Header Upper-->

    <!-- Sticky Header  -->
    <div class="sticky-header">
        <div class="auto-container clearfix">
            <!--Logo-->
            <div class="logo pull-left">
                <a href="<?php echo e(route('home_path')); ?>" title=""><img src="images/logo.png" alt="" title=""></a>
            </div>
            <!--Right Col-->
            <div class="pull-right">
                <!-- Main Menu -->
                <nav class="main-menu clearfix">
                    <!--Keep This Empty / Menu will come through Javascript-->
                </nav><!-- Main Menu End-->
            </div>
        </div>
    </div><!-- End Sticky Menu -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><span class="icon flaticon-close"></span></div>
        <nav class="menu-box">
            <div class="nav-logo"><a href="<?php echo e(route('home_path')); ?>"><img src="images/logo.png" alt="logo" title="Rock, Paper, Scissors logo"></a></div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
            <!--Social Links-->
            <div class="social-links">
              <ul class="clearfix">
                <li><a href="https://www.facebook.com/jessica.khairallah" target="_blank"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="https://www.instagram.com/jessicakhairallah93/" target="_blank"><span class="fab fa-instagram"></span></a></li>
                <li><a href="https://www.linkedin.com/in/jessica-khairallah-996a5385/" target="_blank"><span class="fab fa-linkedin"></span></a></li>
              </ul>
            </div>
        </nav>
    </div><!-- End Mobile Menu -->
</header>
<!-- End Main Header --><?php /**PATH /home/vagrant/Code/game/resources/views/layouts/header.blade.php ENDPATH**/ ?>