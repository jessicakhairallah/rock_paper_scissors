@extends('layouts.app')

@section('content')

<section class="page-banner" style="background-image:url(images/background/title-bg.jpg);">
  <div class="auto-container">
    <div class="inner-container clearfix">
      <ul class="bread-crumb clearfix">
        <li><a href="{{route('home_path')}}">Home</a></li>
        <li>Contact</li>
      </ul>
      <h1>Contact Us</h1>
    </div>
  </div>
</section>

<section class="matches-section" id="view-demo">
  <div class="auto-container">
    <div class="sec-title centered">
      <div class="title">Now it's your turn!</div>
      <h2>Play</h2>
    </div>
    
    <div class="matches-info-tabs">
      <div class="matches-tabs tabs-box">
      
        <ul class="tab-btns tab-buttons clearfix">
          <li data-tab="#prod-all" class="tab-btn active-btn"><span>Play</span></li>
        </ul>
        
        <div class="tabs-content">
          
          <div class="tab active-tab" id="prod-all">
            <div class="content">
              
              <div class="matches-block">
                <div class="inner-block">
                  <div class="row clearfix">
                    
                    <div class="match-column col-lg-12 col-md-12 col-sm-12">
                      <div class="inner-column">
                        <div class="row clearfix">
                          
                          <div class="match-item col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-item">
                              <div class="icon-box" id="player-box">
                                <span class="icon flaticon-crown"></span>
                              </div>
                              <a class="product">You</a>
                             <div class="news-block col-lg-12w col-md-12w col-sm-12w options-block">
                              <div class="inner-box hvr-bob">
                                <div class="lower-content lower-content2">
                                  <div class="post-date post-date2" onclick="selectOption(1)"><i class="fa fa-hand-rock"></i></div>
                                  <div class="post-date post-date2" onclick="selectOption(2)"><i class="fa fa-hand-paper"></i></div>
                                  <div class="post-date post-date2" onclick="selectOption(3)"><i class="fa fa-hand-scissors"></i></div>
                                </div>
                              </div>
                            </div>
                            </div>
                          </div>
                          
                          <div class="match-item col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-item">
                              <div class="icon-box" id="player-box2">
                                <span class="icon flaticon-wolf"></span>
                              </div>
                              <a class="product">Computer</a>
                            </div>
                          </div>

                        </div>
                      </div>
                    </div>
                    
                  </div>
                </div>
              </div>                
              
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</section>

<form>
    <input type="hidden" name="_token" value="{{ csrf_token() }}">
</form>

<script type="text/javascript">
  
  function selectOption(option){
    //empty old selection of player
    $('#player-box').html('<span class="icon flaticon-crown"></span>');

    $('#player-box').html('<img src="/images/results/'+option+'.png" >');

    //empty old selection of computer
    $('#player-box2').html('<span class="icon flaticon-wolf"></span>');
    //generate a random number between 1 and 3 for c1 and c2
    var rand=randomNumberFromRange(1, 3);
    $('#player-box2').html('<img src="/images/results/'+rand+'.png" >');

    // ajax call to compare the results
    $.ajax({
      url: '/play',
      method: "POST",
      data: {
              'player' : option,
              'computer' : rand
            },
      headers: {
         'X-CSRF-Token': $('input[name=_token]').val()
      },                      
      dataType: "json",

      success: function (msg) {
              swal({
                    title: "Result!",
                    text: msg, 
                  }); 
              },
      error: function(jqXHR, textStatus, errorThrown) {

            console.log('Status:'+jqXHR.status);
            console.log('Text status:'+textStatus);
            console.log('Error Thrown:'+errorThrown);
        }

    });

  }

  //function to get random numbers between 1 and 3
  function randomNumberFromRange(min,max)
  {
    return Math.floor(Math.random()*(max-min+1)+min);
  }

</script>
@endsection