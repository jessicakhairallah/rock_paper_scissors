<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Auth;
use Mail;

class FrontendController extends Controller
{
    //home page
    public function index()
    {      
        return view('index');
    }

    //play page
    public function play()
    {      
        return view('play');
    }

    //play action
    public function playAction(Request $request)
    {   
        //put chosen options in variables
        $p = $request->input('player');
        $c = $request->input('computer');

        //declare message variable
        $msg = '';

        //if rock vs rock || paper vs paper || scissors vs scissors
        if( ($p==1 && $c==1) || ($p==2 && $c==2) || ($p==3 && $c==3) )
        {
          $msg = 'Draw!!!';
        }
        //if rock vs paper || paper vs scissors || scissors vs rock
        if( ($p==1 && $c==2) || ($p==2 && $c==3) || ($p==3 && $c==1) )
        {
          $msg = 'Sorry You Lost!!!';
        }
        //if rock vs scissors || paper vs rock || scissors vs paper
        if( ($p==1 && $c==3) || ($p==2 && $c==1) || ($p==3 && $c==2) )
        {
          $msg = 'You Won!!!';
        }
        
        return response()->json($msg);  

    }

}
