<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/* Homepage */
Route::get('/', [
    'as' => 'home_path',
    'uses' => 'FrontendController@index'
]);


/* Play */
Route::get('/play', [
    'as' => 'play_path',
    'uses' => 'FrontendController@play'
]);


/* Play */
Route::post('/play', [
    'as' => 'play_action',
    'uses' => 'FrontendController@playAction'
]);
